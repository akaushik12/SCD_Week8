use StagingTable

Select * from employeedata

Create table DIM_TABLE (
			DimpEmpID int Identity(1,1) Primary key not null,
			ID int not null,
			First varchar(50),
			Last varchar(50),
			Rate float,
			Title varchar(50),
			Zip int,
			StartDate DateTime,
			EndDate DateTime,
			LastUpdateddate DateTime,
			PriorZip int
			)

Select * from DIM_TABLE


-- 2. Zip code change to Betty Rubble

Update employeedata set Zip = 02903 where ID=4  

Select * from employeedata
Select * from DIM_TABLE

-- 3. John changes name

Update employeedata set First = 'Jon' where ID=1 

Select * from employeedata
Select * from DIM_TABLE

-- 4. Bob Gets a a raise

Update employeedata set Rate = 30.25 where ID=2 

Select * from employeedata
Select * from DIM_TABLE

-- 5. New Record

Insert into employeedata values(5, 'Chris', 'Roberts', 12, 'Marketing', 2901)

Select * from employeedata
Select * from DIM_TABLE

-- 6. Bob Jones Updates Name

Update employeedata set Last = 'Robert' where ID=2 

Select * from employeedata
Select * from DIM_TABLE

-- 7. Delete / Terminate a record

Delete From employeedata where id =3

Select * from employeedata
Select * from DIM_TABLE



